# Simple Online Book Store

### Admin User
- **uersname**: admin
- **password**: admin123
